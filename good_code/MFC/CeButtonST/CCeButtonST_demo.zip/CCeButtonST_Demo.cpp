#include "stdafx.h"
#include "CCeButtonST_Demo.h"
#include "CCeButtonST_DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CCCeButtonST_DemoApp, CWinApp)
	//{{AFX_MSG_MAP(CCCeButtonST_DemoApp)
	//}}AFX_MSG
END_MESSAGE_MAP()

CCCeButtonST_DemoApp::CCCeButtonST_DemoApp()
	: CWinApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCCeButtonST_DemoApp object

CCCeButtonST_DemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCCeButtonST_DemoApp initialization

BOOL CCCeButtonST_DemoApp::InitInstance()
{
	CCCeButtonST_DemoDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	return FALSE;
} // End of InitInstance
