#ifndef _CCEBUTTONST_DEMO_H_
#define _CCEBUTTONST_DEMO_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

class CCCeButtonST_DemoApp : public CWinApp
{
public:
	CCCeButtonST_DemoApp();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCeButtonST_DemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CCCeButtonST_DemoApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif 
