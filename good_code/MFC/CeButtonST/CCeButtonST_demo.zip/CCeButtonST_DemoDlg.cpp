#include "stdafx.h"
#include "CCeButtonST_Demo.h"
#include "CCeButtonST_DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDS_WEBADDR		_T("http://www.softechsoftware.it")
#define IDS_MAILADDR	_T("mailto:davide_calabro@yahoo.com")

CCCeButtonST_DemoDlg::CCCeButtonST_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCCeButtonST_DemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCCeButtonST_DemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCCeButtonST_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCCeButtonST_DemoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	// Make our buttons a CCeButtonST buttons
	DDX_Control(pDX, IDC_BTNSTANDARD, m_btnStandard);
	DDX_Control(pDX, IDC_BTNKEYMANAGER, m_btnKeyManager);
	DDX_Control(pDX, IDC_BTNDISABLED, m_btnDisabled);
	DDX_Control(pDX, IDC_BTNSEARCH, m_btnSearch);
	DDX_Control(pDX, IDC_BTNBACK, m_btnBack);
	DDX_Control(pDX, IDC_BTNNEXT, m_btnNext);
	DDX_Control(pDX, IDC_BTNLAMP, m_btnLamp);
	DDX_Control(pDX, IDC_CHECK, m_chkCheckbox);

	DDX_Control(pDX, IDC_HOMEPAGELINK, m_btnWeb);
	DDX_Control(pDX, IDC_EMAILLINK, m_btnMail);
}

BEGIN_MESSAGE_MAP(CCCeButtonST_DemoDlg, CDialog)
	//{{AFX_MSG_MAP(CCCeButtonST_DemoDlg)
	ON_BN_CLICKED(IDC_BTNDISABLED, OnBtnDisabled)
	ON_COMMAND(IDM_ITEM1, OnItem1)
	ON_COMMAND(IDM_ITEM2, OnItem2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CCCeButtonST_DemoDlg::OnInitDialog()
{
	COLORREF	crBtnColor;

	CDialog::OnInitDialog();

	// Calculate a color effect for hilighting the button
	crBtnColor = ::GetSysColor(COLOR_BTNFACE) + RGB(30, 30, 30);

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	
	CenterWindow(GetDesktopWindow());

	// Standard button
	m_btnStandard.SetFont(GetFont());
	m_btnStandard.SetIcon(IDI_EOAPP, CSize(32, 32));
	m_btnStandard.SetFlat(FALSE);
	// 48x48 icon button
	m_btnKeyManager.SetFont(GetFont());
	m_btnKeyManager.SetIcon(IDI_KEYMANAGER, CSize(48, 48));
	m_btnKeyManager.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);
	// Disabled button
	m_btnDisabled.SetFont(GetFont());
	m_btnDisabled.SetIcon(IDI_SOUND1, CSize(32, 32), NULL, CSize(32, 32), IDI_SOUND2, CSize(32, 32));
	m_btnDisabled.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);
	// Search button
	m_btnSearch.SetFont(GetFont());
	m_btnSearch.SetIcon(IDI_SEARCH1, CSize(32, 32), IDI_SEARCH2, CSize(32, 32));
	m_btnSearch.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);
	m_btnSearch.SetAlign(CCeButtonST::ST_ALIGN_VERT);
	m_btnSearch.SetMenu(IDR_MENU, m_hWnd);
	// Back button
	m_btnBack.SetFont(GetFont());
	m_btnBack.SetIcon(IDI_LEFT6, CSize(32, 32));
	m_btnBack.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);
	m_btnBack.SetColor(CCeButtonST::BTNST_COLOR_FG_IN, RGB(0, 128, 0));
	m_btnBack.SetRounded(TRUE);
	// Next button
	m_btnNext.SetFont(GetFont());
	m_btnNext.SetIcon(IDI_RIGHT6, CSize(32, 32));
	m_btnNext.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);
	m_btnNext.SetColor(CCeButtonST::BTNST_COLOR_FG_IN, RGB(0, 128, 0));
	m_btnNext.SetAlign(CCeButtonST::ST_ALIGN_HORIZ_RIGHT);
	m_btnNext.SetRounded(TRUE);
	// Lamp button
	m_btnLamp.SetFont(GetFont());
	m_btnLamp.SetIcon(IDI_LAMP1, CSize(32, 32), IDI_LAMP2, CSize(32, 32));
	m_btnLamp.DrawBorder(FALSE);
	// Checkbox
	m_chkCheckbox.SetFont(GetFont());
	m_chkCheckbox.SetIcon(IDI_LEDON, CSize(16, 16), IDI_LEDOFF, CSize(16, 16));
	m_chkCheckbox.SetColor(CCeButtonST::BTNST_COLOR_BK_IN, crBtnColor);

	// Other buttons
	m_btnWeb.SetFont(GetFont());
	m_btnWeb.SetIcon(IDI_WEB, CSize(16,16));
	m_btnWeb.SetBtnCursor(IDC_HAND1, FALSE);
	m_btnWeb.SetURL(IDS_WEBADDR);
	//
	m_btnMail.SetFont(GetFont());
	m_btnMail.SetIcon(IDI_MAIL, CSize(16,16));
	m_btnMail.SetURL(IDS_MAILADDR);

	return TRUE;
} // End of OnInitDialog

void CCCeButtonST_DemoDlg::OnBtnDisabled() 
{
	// Change button text
	m_btnDisabled.SetWindowText(_T("Disabled"));
	// Disable the button
	m_btnDisabled.EnableWindow(FALSE);
} // End of OnBtnDisabled

void CCCeButtonST_DemoDlg::OnItem1() 
{
	MessageBox(_T("Selected <Option 1>"), _T("Menu selection"), MB_ICONINFORMATION);
} // End of OnItem1

void CCCeButtonST_DemoDlg::OnItem2() 
{
	MessageBox(_T("Selected <Option 2>"), _T("Menu selection"), MB_ICONINFORMATION);
} // End of OnItem2
