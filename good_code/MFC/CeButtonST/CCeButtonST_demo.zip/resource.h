//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CCeButtonST_Demo.rc
//
#define IDD_CCEBUTTONST_DEMO_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDI_WEB                         129
#define IDI_MAIL                        130
#define IDI_SEARCH2                     131
#define IDI_SEARCH1                     132
#define IDI_EOAPP                       133
#define IDI_KEYMANAGER                  134
#define IDI_RIGHT2                      136
#define IDI_LEFT2                       137
#define IDI_SOUND1                      138
#define IDI_SOUND2                      139
#define IDI_LAMP2                       140
#define IDI_LAMP1                       141
#define IDI_LEDON                       142
#define IDI_LEDOFF                      143
#define IDC_HAND1                       144
#define IDR_MENU                        145
#define IDI_LEFT6                       146
#define IDI_RIGHT6                      147
#define IDC_EMAILLINK                   1000
#define IDC_HOMEPAGELINK                1001
#define IDC_BTNSTANDARD                 1002
#define IDC_BTNSEARCH                   1003
#define IDC_BTNKEYMANAGER               1004
#define IDC_BTNBACK                     1005
#define IDC_BTNNEXT                     1006
#define IDC_BTNDISABLED                 1007
#define IDC_BTNLAMP                     1008
#define IDC_CHECK                       1009
#define IDM_ITEM1                       32771
#define IDM_ITEM2                       32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
