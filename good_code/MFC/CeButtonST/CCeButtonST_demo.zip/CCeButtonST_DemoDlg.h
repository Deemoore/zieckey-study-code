#ifndef _CCEBUTTONST_DEMODLG_H_
#define _CCEBUTTONST_DEMODLG_H_

#include "CeBtnST.h"
#include "WinXPButtonST.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CCCeButtonST_DemoDlg : public CDialog
{
public:
	CCCeButtonST_DemoDlg(CWnd* pParent = NULL);

	//{{AFX_DATA(CCCeButtonST_DemoDlg)
	enum { IDD = IDD_CCEBUTTONST_DEMO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCCeButtonST_DemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCCeButtonST_DemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnDisabled();
	afx_msg void OnItem1();
	afx_msg void OnItem2();
	//}}AFX_MSG

private:
	CCeButtonST		m_btnStandard;
	CCeButtonST		m_btnSearch;
	CCeButtonST		m_btnKeyManager;
	CCeButtonST		m_btnDisabled;
	CCeButtonST		m_btnLamp;
	CCeButtonST		m_chkCheckbox;
	CCeButtonST		m_btnWeb;
	CCeButtonST		m_btnMail;
	CWinXPButtonST	m_btnBack;
	CWinXPButtonST	m_btnNext;

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif
