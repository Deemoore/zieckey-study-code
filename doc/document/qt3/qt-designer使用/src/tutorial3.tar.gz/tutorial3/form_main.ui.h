/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/


void form_main::addSlot()
{
    QString str1, str2, strResult;
    double add1 = 0.0, add2 = 0.0, result = 0.0;
    
    //�õ�������ַ�
    str1 = lineEditAdd1->text();
    str2 = lineEditAdd2->text();
    
    //ת��Ϊ����
    bool ok1 = FALSE, ok2 = FALSE;
    add1 = str1.toDouble( &ok1 );
    add2 = str2.toDouble( &ok2 );
    
    if ( ok1 &&  ok2 )
    {	//������� �������ֵĻ�
	result = add1 + add2;
	strResult.sprintf( "%f + %f = %f", add1, add2, result );
	textLabelResult->setText( strResult );
    }
    else
    {	
	QMessageBox::warning( this, "Input Error",
        "Could not convert the input to the numbers\n"
        "Please try again.\n\n",
        "Retry",
        "Quit", 0, 0, 1 );
    }
}
