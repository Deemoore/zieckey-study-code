#include <qapplication.h>
#include "form_main.h"

int main( int argc, char ** argv )
{
    QApplication a( argc, argv );
    form_main w;
    w.show();
    a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );
    return a.exec();
}
