/****************************************************************************
** Form implementation generated from reading ui file 'mainform.ui'
**
** Created: �� 11�� 5 16:25:05 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.1   edited Nov 21 17:40 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "mainform.h"

#include <qvariant.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/* 
 *  Constructs a MainForm as a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
MainForm::MainForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )

{
    if ( !name )
	setName( "MainForm" );

    showMsgLineEdit = new QLineEdit( this, "showMsgLineEdit" );
    showMsgLineEdit->setGeometry( QRect( 150, 230, 350, 21 ) );

    openButton = new QPushButton( this, "openButton" );
    openButton->setGeometry( QRect( 150, 70, 91, 30 ) );
    languageChange();
    resize( QSize(600, 480).expandedTo(minimumSizeHint()) );

    // signals and slots connections
    connect( openButton, SIGNAL( clicked() ), this, SLOT( openDBSlot() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
MainForm::~MainForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void MainForm::languageChange()
{
    setCaption( tr( "A test Showing how to connect SQLite3 in QT3" ) );
    openButton->setText( tr( "Open DB" ) );
}

void MainForm::openDBSlot()
{
    //qWarning( "MainForm::openDBSlot(): Not implemented yet" );
    sqlite3 *db=NULL;
    int rc;
    rc = sqlite3_open("zieckey.db", &db); //��ָ�������ݿ��ļ�,��������ڽ�����һ��ͬ�������ݿ��ļ�
    if( rc )
	{
		QString errMsgQString;
		errMsgQString.sprintf("Can't open database: %s\n", sqlite3_errmsg(db) );
		showMsgLineEdit->setText(errMsgQString);
		sqlite3_close(db);
    }
    else 
		showMsgLineEdit->setText( "open zieckey.db successfully!\n" );

    sqlite3_close(db); //�ر����ݿ�
}

