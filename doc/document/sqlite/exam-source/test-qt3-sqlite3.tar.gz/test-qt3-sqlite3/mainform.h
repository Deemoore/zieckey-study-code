/****************************************************************************
** Form interface generated from reading ui file 'mainform.ui'
**
** Created: �� 11�� 5 16:24:45 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.1   edited Nov 21 17:40 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef MAINFORM_H
#define MAINFORM_H

#include <qvariant.h>
#include <qdialog.h>

#include "sqlite3.h"            //ע�⣬����һ��Ҫ���ӽ���


class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QLineEdit;
class QPushButton;

class MainForm : public QDialog
{
    Q_OBJECT

public:
    MainForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MainForm();

    QLineEdit* showMsgLineEdit;
    QPushButton* openButton;

public slots:
    virtual void openDBSlot();         //ע�⣬�������½���һ��SLOT

protected:

protected slots:
    virtual void languageChange();
};

#endif // MAINFORM_H
