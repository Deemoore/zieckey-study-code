#!/bin/sh
echo
echo "================= aclocal ================= "
echo
aclocal
echo

echo
echo "================= autoconf ================= "
echo
autoconf
echo

echo
echo "================= automake ================= "
echo
echo
automake
echo

echo
echo "================= configure ================= "
declare workdir=$(pwd);
./configure --prefix=${workdir}/../../../server/trunk/debug/lib
